import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService, CommonService, SignalrService } from '../_core/services';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  loading = false;
  hide=false;
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private commonService: CommonService,
    private signalrService:SignalrService
    ) { }

  ngOnInit() {
    SignalrService.getInstance();
    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      name: ['', Validators.required],
      password: ['', [Validators.required,Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]
    })
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.registerForm.controls[controlName].hasError(errorName);
  }

  onSubmit(formData) {
   this.signalrService.sendMessage();

    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }
    this.commonService.showSpinner();
    this.userService.register(formData)
      .subscribe(
        response => {
          if (this.commonService.validateAPIResponse(response) == true) {
            this.commonService.showSuccessMessage("Registration successful , please login to your account.")
            this.router.navigate([""]);
          }
          this.commonService.hideSpinner();
        })
  }

}
