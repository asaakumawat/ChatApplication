import { Component } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import { copyStyles } from '@angular/animations/browser/src/util';
import { fadeAnimation } from './shared/animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  animations:[fadeAnimation]

})
export class AppComponent {
  title = 'sh-app';
  selectedLang="English";
  lang=["en","hi"]
  langFullName=["English","हिंदी"]
  constructor(public translate: TranslateService) {
    translate.addLangs(this.lang);
    translate.setDefaultLang('hi');
    //const browserLang = translate.getBrowserLang();
    var browserLang = localStorage.getItem('browserLang');
    if(!browserLang)
      browserLang="en"
    this.selectedLang=this.langFullName[this.lang.indexOf(browserLang)];
    translate.use(browserLang.match(/en|hi/) ? browserLang : 'en');
  }
  changeLanguage(language)
  {
    //console.log(this.langFullName.indexOf(language));
    var browserLang=this.lang[this.langFullName.indexOf(language)];
    console.log(browserLang)
    localStorage.setItem('browserLang',browserLang);
    this.translate.use(browserLang);
  }
}
