import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { Router, ActivatedRoute } from '@angular/router'
import { AuthenticationService, CommonService, SignalrService } from '../_core/services'
import { Utils } from '../_core/helpers'
import { NotifierService } from 'angular-notifier';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  loading = false;
  returnUrl: String;
  rememberMe = false;
  hide=false;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
    private signalrService:SignalrService
  ) { }

  ngOnInit() {
    SignalrService.getInstance();
    this.RedirectUserIfLoggedIn();
    this.loginForm = this.formBuilder.group({
      username: [localStorage.getItem('loginUserName'), Validators.required],
      password: [localStorage.getItem('loginPassword'), Validators.required]
    })
    //this.loginForm.setValue
    // reset login status
    this.authenticationService.logout();
  }
  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }
  public hasError = (controlName: string, errorName: string) => {
    return this.loginForm.controls[controlName].hasError(errorName);
  }

  onSubmit(formData) {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.commonService.showSpinner();
    this.authenticationService.login(formData)
      .subscribe(
        response => {
          this.commonService.hideSpinner();
          if (this.commonService.validateAPIResponse(response) == true) {
            // this.route.queryParams.subscribe(a => {
            //   if (a)
            //     this.returnUrl = a["returnUrl"]
            // })
            // console.log(this.returnUrl)
            this.ManageRememberMe()

            if (this.returnUrl) {
              this.router.navigate([this.returnUrl]);
            }
            else {
              if (response.data.isadmin == true) {
                this.router.navigate(["admin"]);
              }
              else {
                this.router.navigate(["user"]);
              }
            }
          }
        }
        // ,
        // error=>
        // {
        //   alert('Error...')
        //   this.loading = false;
        // }
      )
  }

  RedirectUserIfLoggedIn() {
    if (this.authenticationService.IsLoggedIn() && this.authenticationService.IsAdminLoggedIn()) {
      this.router.navigate(["admin"]);
    }
    else if (this.authenticationService.IsLoggedIn() && this.authenticationService.IsMemberLoggedIn()) {
      this.router.navigate(["member"]);
    }
  }
  rememberMeChanged() {
    this.rememberMe = !this.rememberMe;
  }
  ManageRememberMe() {
    localStorage.removeItem('loginUserName');
    localStorage.removeItem('loginPassword');
    if (this.rememberMe) {
      localStorage.setItem('loginUserName', this.loginForm.controls['username'].value);
      localStorage.setItem('loginPassword', this.loginForm.controls['password'].value);
    }
  }
}
