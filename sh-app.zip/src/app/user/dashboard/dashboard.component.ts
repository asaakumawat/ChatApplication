import { Component, OnInit } from '@angular/core';
import { fadeAnimation } from '../../shared/animations';

@Component({
  selector: 'user-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  
  animations:[fadeAnimation]
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
