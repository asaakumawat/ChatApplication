import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService, CommonService } from 'src/app/_core/services';
import { NotifierService } from 'angular-notifier';
import { Utils } from '../../_core/helpers'
import { fadeAnimation } from '../../shared/animations';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
  animations:[fadeAnimation]
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;
  genders: string[];
  submitted = false;
  loading = false;
  maxDate = new Date();
  profilePicture: File = null;
  selectedFileName: String;
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private notifier: NotifierService,
    private commonService: CommonService) { }

  ngOnInit() {
    this.genders = Utils.Genders;
    this.profileForm = this.formBuilder.group({
      fullname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      mobileno: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      gender: ['', Validators.required],
      dob: ['', Validators.required],
      profileimg: ['']
    })
    // this.profileForm.valueChanges.subscribe(data => this.loading=false);
    this.commonService.showSpinner();
    this.userService.getUserProfile(this.commonService.getCurrentUserId())
      .subscribe(response => {
       // console.log(response);
        if (!this.commonService.validateAPIResponse(response)) {
          return; // show error message and return in case of any error from API
        }
        if (response.data) {
          //this.profileForm.setValue(response.data);
          var userProfile = response.data;
          console.log(userProfile);
          if (!userProfile.dob) {
            userProfile.dob = this.maxDate;
          }
          this.profileForm.setValue({ fullname: userProfile.fullname||'', email: userProfile.email||'', mobileno: userProfile.mobileno||'', gender: userProfile.gender||'', dob: userProfile.dob, profileimg: userProfile.profileimg||'' });

        }
      })
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.profileForm.controls[controlName].hasError(errorName);
  }

  onSubmit(inputs) {
    this.submitted = true;
    if (this.profileForm.invalid) {
      return;
    }
    inputs.userid = this.commonService.getCurrentUserId();

    let formData = new FormData();
    formData.append("profilepic", this.profilePicture);
    for (var key in inputs) {
      if (inputs.hasOwnProperty(key)) {
        formData.append(key, inputs[key]);
      }
    }
    this.loading=true;
    this.commonService.showSpinner();
    this.userService.saveUserProfile(formData)
      .subscribe(
        response => {
          if (!this.commonService.validateAPIResponse(response)) {
            this.loading=false;
            return; // show error message and return in case of any error from API
          }
          var currentUser=this.commonService.getCurrentUser();
          if(currentUser)
          {
            currentUser.profileimg=response.data.profileimg;
            currentUser.fullname=response.data.fullname;
            this.commonService.updateCurrentUser(currentUser);
          }
          this.loading=false;
          this.commonService.showSuccessMessage("Profile updated successfully.")
          this.router.navigate(["/user/profile"]);
          //window.location.reload();
        }
      )
  }
  clickUpload() {
    document.getElementById('profilepic').click()
  }
  onFileUpload(files: FileList) {
    this.profilePicture = files.item(0);
    console.log(this.profilePicture.name)
    if (this.profilePicture) {
      if (this.profilePicture.name.length > 30) {
        this.selectedFileName = this.profilePicture.name.substring(0, 30);
      }
      else {
        this.selectedFileName = this.profilePicture.name;
      }
    }
  }
}
