import { Component, OnInit, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { CommonService, ContentManagerService } from 'src/app/_core/services';
import { Router } from '@angular/router';
import { MatSort, MatPaginator } from '@angular/material';

@Component({
  selector: 'app-content-manager',
  templateUrl: './content-manager.component.html',
  styleUrls: ['./content-manager.component.scss']
})
export class ContentManagerComponent implements OnInit {
  displayedColumns: string[] = ['title', 'actions'];
  contentSource: [];
  pageSize = 10;
  pageIndex = 0;
  totalSize = 0;
  constructor(
    private router: Router,
    private commonService: CommonService,
    private contentManagerService: ContentManagerService) { }

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  ngOnInit() {
    // If the user changes the sort order, reset back to the first page.
    this.sort.sortChange.subscribe(() => {console.log('on sort change'); this.paginator.pageIndex = 0;this.pageIndex=0; this.getContentDataFromAPI(); });
    this.getContentDataFromAPI();
  }
  getContentDataFromAPI() {
    this.contentSource = []
    var currentUserId = this.commonService.getCurrentUserId();
    this.contentManagerService.getAllContentsbyUserId(currentUserId,this.pageSize,this.pageIndex,(this.sort.active||'title'), (this.sort.direction||'asc')).subscribe(response => {
      console.log(response);
      if (!this.commonService.validateAPIResponse(response)) {
        return; // show error message and return in case of any error from API
      }
      this.contentSource = response.data.items;
      this.totalSize=response.data.totalitems;

    })
  }

  onContentDelete(contentId) {
    if (confirm("Are you sure to delete content?")) {
      this.contentManagerService.deleteContent(contentId).subscribe(response => {
        if (!this.commonService.validateAPIResponse(response)) {
          return; // show error message and return in case of any error from API
        }
        this.commonService.showSuccessMessage("Content deleted successfully.")
        this.getContentDataFromAPI();
      })
    }
  }
  handlePage(e: any) {
    console.log('on page change')
    this.pageIndex = e.pageIndex;
    this.pageSize = e.pageSize;
    this.getContentDataFromAPI();
  }

}
