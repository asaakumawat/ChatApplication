import { Component, OnInit, Input } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import { CommonService, ContentManagerService } from 'src/app/_core/services';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-edit-content-manager',
  templateUrl: './add-edit-content-manager.component.html',
  styleUrls: ['./add-edit-content-manager.component.scss']
})

export class AddEditContentManagerComponent implements OnInit {
  submitted = false;
  loading = false;
  contentForm: FormGroup;
  contentId: string;
  config = {
    height: '200px',
    uploadImagePath: environment.apiurl + 'content-manager/uploadImages',
    toolbar: [
      ['edit',['undo','redo']],
            ['headline', ['style']],
            // ['style', ['bold', 'italic', 'underline', 'superscript', 'subscript', 'strikethrough', 'clear']],
            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['fontface', ['fontname']],
            ['textsize', ['fontsize']],
            ['fontclr', ['color']],
            ['alignment', ['ul', 'ol', 'paragraph', 'lineheight']],
            ['height', ['height']],
            ['table', ['table']],
            ['insert', ['link','picture','video','hr']],
            ['view', ['fullscreen', 'codeview']],
            ['help', ['help']]
  ],
  };
  get sanitizedHtml() {
    return this.sanitizer.bypassSecurityTrustHtml(this.contentForm.get('html').value);
  }

  constructor(
    private router: Router,
    private sanitizer: DomSanitizer,
    private formBuilder: FormBuilder,
    private activeRoute: ActivatedRoute,
    private commonService: CommonService,

    private contentManagerService: ContentManagerService) { }

  ngOnInit() {
    this.contentForm = this.formBuilder.group({
      title: ['', Validators.required],
      content: ['', Validators.required],
    })
    this.activeRoute.params.subscribe(params => {
      if (params['id']) {
        this.contentId = params['id'];
      }
    })
    if (this.contentId) {
      this.commonService.showSpinner();
      this.contentManagerService.getContentById(this.contentId).subscribe(response => {
        console.log(response);
        if (!this.commonService.validateAPIResponse(response)) {
          return;
        }
        if (response.data) {
          var contentData = response.data;
          console.log(contentData);
          this.contentForm.setValue({ title: contentData.title || '', content: contentData.content });
        }
      });
    }
  }
  public hasError = (controlName: string, errorName: string) => {
    return this.contentForm.controls[controlName].hasError(errorName);
  }

  // onBlur() {
  //   console.log('Blur');
  // }
  onSubmit(formData) {
    this.submitted = true;
    if (this.contentForm.invalid) {
      return;
    }
    formData.userid = this.commonService.getCurrentUserId();
    formData.id = this.contentId;
    this.commonService.showSpinner();
    this.contentManagerService.saveContent(formData)
      .subscribe(
        response => {
          if (!this.commonService.validateAPIResponse(response)) {
            this.loading = false;
            return; // show error message and return in case of any error from API
          }
          this.loading = false;
          this.commonService.showSuccessMessage("Content updated successfully.")
          this.router.navigate(["/user/content-manager"]);
          //window.location.reload();
        }
      )
  }
}
