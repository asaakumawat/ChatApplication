import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './shared/layout/layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { ContentManagerComponent } from './content-manager/content-manager.component'
import { AddEditContentManagerComponent } from './content-manager/add-edit-content-manager/add-edit-content-manager.component'

const routes: Routes = [
  {
    path: '', component: LayoutComponent,
    children: [
      { path: '', component: DashboardComponent },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'content-manager', component: ContentManagerComponent },
      { path: 'content-manager/add', component: AddEditContentManagerComponent },
      { path: 'content-manager/edit/:id', component: AddEditContentManagerComponent }
    ]
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
