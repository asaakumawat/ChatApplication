import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { MaterialModule } from '../shared/material-module';
import { UserRoutingModule } from './user-routing.module';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { AppSidebarComponent} from './shared/sidebar/sidebar.component';
import { LayoutComponent } from './shared/layout/layout.component';

import { MenuItems } from './shared/menu-items';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ProfileComponent } from './profile/profile.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { HttpLoaderFactory } from '../app.module';
import { NotifierModule } from 'angular-notifier';
import { CustomNotifierOptions } from '../shared/customnotifieroptions';
import { HttpClient } from '@angular/common/http';
import{NumberDirective} from '../shared/directives';
import { ContentManagerComponent } from './content-manager/content-manager.component';
import { AddEditContentManagerComponent } from './content-manager/add-edit-content-manager/add-edit-content-manager.component'

@NgModule({
  declarations: [HeaderComponent,FooterComponent,AppSidebarComponent, LayoutComponent
    ,DashboardComponent, ProfileComponent,NumberDirective, ContentManagerComponent, AddEditContentManagerComponent],
  imports: [
    CommonModule,
    SharedModule,
    MaterialModule,
    UserRoutingModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    NotifierModule.withConfig(CustomNotifierOptions.getCustomOptions())
  ],
  exports: [
    SharedModule
   ],
  providers:[
    MenuItems
  ]
})

export class UserModule { }
