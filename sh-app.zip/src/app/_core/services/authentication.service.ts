import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import { map, retryWhen } from 'rxjs/operators';

import {User} from '../models'
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { CommonService } from './common.service'

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  
  constructor(private http:HttpClient,private commonService:CommonService) { }
  
  login(data):Observable<any>
  {
    return this.http.post<any>(environment.apiurl+'user/login', data)
            .pipe(map(response => { 
             // console.log(response)
              if(!response || !response.success)
              {
                return response;
              }
              this.commonService.updateCurrentUser(response.data);
              //localStorage.setItem('currentUser', JSON.stringify(response.data));
              return response;
            }));
  }
  IsLoggedIn()
  {
    if (localStorage.getItem('currentUser')) {
        return true;
    }
    return false;
  }
  IsAdminLoggedIn()
  {
    if (localStorage.getItem('currentUser')) {
        return true;
    }
    return false;
  }
  IsMemberLoggedIn()
  {
    if (localStorage.getItem('currentUser')) {
        return true;
    }
    return false;
  }
  logout()
  {
    localStorage.removeItem("currentUser");
  }
}
