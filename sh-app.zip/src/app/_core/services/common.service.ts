import { Injectable } from '@angular/core';

import { NotifierService } from 'angular-notifier';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { environment } from 'src/environments/environment';
import { Subject, Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  private subject = new Subject<any>();
  constructor(
    private notifier: NotifierService,
    private spinnerService: Ng4LoadingSpinnerService
  ) { }

  validateAPIResponse(response) {
    this.hideSpinner();
    if (!response) {
      return false;
    }
    else if (response.success == false) {
      if (!response.message) {
        response.message = "Something went worng . Try again."
      }
      this.showErrorMessage(response.message)
      return false;
    }
    else if (response.success == true) {
      return true;
    }
    return false;
  }
  showSuccessMessage(message: string) {
    this.notifier.notify("success", message);
  }
  showErrorMessage(message: string) {
    this.notifier.notify("error", message);
  }
  showSpinner() {
    this.spinnerService.show();
  }
  hideSpinner() {
    //(<HTMLElement>document.querySelector('.spinner')).style.visibility = 'hidden';
    //(<HTMLElement>document.getElementsByClassName('spinner')[0].style.visibility = "visible";
    this.spinnerService.hide();
  }
  getCurrentUser() {
    var user = localStorage.getItem('currentUser');
    // var currentUser=JSON.parse(user);
    // if (currentUser.profileimg) {
    //   currentUser.profileimg=this.appendBaseURLinFilePath(currentUser.profileimg)
    // }
    return JSON.parse(user);;
  }
  getCurrentUserId() {
    var user = this.getCurrentUser();
    if (user)
      return user.id;

    return 0;
  }
  updateCurrentUser(currentUser: any) {
    if (currentUser.profileimg) {
      currentUser.profileimg=this.appendBaseURLinFilePath(currentUser.profileimg)
    }
    this.subject.next(currentUser);
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
  }
  getUserUpdatedDetails(): Observable<any> {
    return this.subject.asObservable();
  }
  appendBaseURLinFilePath(filePath: string) {
    return filePath = environment.apiurl + filePath;
  }
}
