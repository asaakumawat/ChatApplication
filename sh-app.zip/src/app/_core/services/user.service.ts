import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { map } from 'rxjs/operators';

import { User,UserProfile } from '../models'
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  register(user: User): Observable<any> {
    return this.http.post(environment.apiurl + 'user/register', user);
  }
  getUserProfile(userId: number): Observable<any> {
    return this.http.get(environment.apiurl + 'user/profile?userid=' + userId)
  }
  saveUserProfile(userProfile: FormData): Observable<any> {
    var headers:any=new HttpHeaders({"Content-Type":"multipart/form-data"})
    return this.http.post(environment.apiurl + 'user/profile', userProfile,headers);
  }
  getAllUsers(): Observable<any> {
    return this.http.get(environment.apiurl + 'user/getallusers');
  }
  changeStatus(userId): Observable<any> {
    return this.http.post(environment.apiurl + 'user/changestatus?userId='+userId,null);
  }
}
