import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { map } from 'rxjs/operators';

import { User,UserProfile } from '../models'
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ContentManagerService {

  constructor(private http: HttpClient) { }

  saveContent(contentData: any): Observable<any> {
    return this.http.post(environment.apiurl + 'content-manager', contentData);
  }
  getContentById(contentId: string): Observable<any> {
    return this.http.get(environment.apiurl + 'content-manager/' + contentId)
  }
  getAllContentsbyUserId(userId:string,pageSize:Number,pageIndex:Number,shortBy:String,shortDirection:String): Observable<any> {
    return this.http.get(environment.apiurl + `content-manager?userid=${userId}&pageSize=${pageSize}&pageIndex=${pageIndex}&sortBy=${shortBy}&sortDirection=${shortDirection}`);
  }
  deleteContent(contentId): Observable<any> {
    return this.http.post(environment.apiurl + 'content-manager/delete?id='+contentId,null);
  }
}
