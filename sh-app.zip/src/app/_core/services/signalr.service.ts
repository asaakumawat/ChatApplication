import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
declare var $: any;

@Injectable({
  providedIn: 'root'
})
export class SignalrService {

  private connection: any;
  private proxy: any;
  private url: any = environment.apiurl + "signalr";
  private static instance: SignalrService = null;

  constructor() {
  }

  // Return the instance of the service
  public static getInstance(): SignalrService {
    //console.log(SignalrService.instance);
    if (SignalrService.instance === null) {
      SignalrService.instance = new SignalrService();
      SignalrService.instance.startConnection();
    }
    return SignalrService.instance;
  }


  public startConnection(): void {
    SignalrService.instance.connection = $.hubConnection(this.url, { useDefaultPath: false });
    SignalrService.instance.proxy = this.connection.createHubProxy('chatHub');
    SignalrService.instance.proxy.on('messageReceived', (latestMsg) => this.onMessageReceived(latestMsg));
    SignalrService.instance.connection.qs="username=test";
    //console.log(SignalrService.instance.connection);
    SignalrService.instance.connection.start().done((data: any) => {
      console.log('Connected to Processing Hub');
      console.log(SignalrService.instance.connection.user)
      // console.log(data)
      //  this.sendMessage();
    }).catch((error: any) => {
      console.log('Hub error -> ' + error);
    });
  }
  public onMessageReceived(message): void {
    console.log(message);
  };
  public sendMessage(): void {
    SignalrService.instance.proxy.invoke('SendMessage', 'test')
      .catch((error: any) => {
        console.log('SendMessage error -> ' + error);
      });
  }

}
