export class UserProfile {
    id: number;
    userid: string;
    fullname: string;
    email: string;
    mobileno: string;
    gender: string;
  }
  