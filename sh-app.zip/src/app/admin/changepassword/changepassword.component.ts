import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { UserProfile } from 'src/app/_core/models';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: []
})
export class ChangepasswordComponent implements OnInit {
  model: any = {};
  submitted = false;
  constructor( public dialogRef: MatDialogRef<ChangepasswordComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UserProfile) { }

  ngOnInit() {
    console.log(this.data);
  }
  onCancelClick()
  {
    this.dialogRef.close();
  }
  onSubmit()
  {
    this.submitted=true;
    console.log(this.model);
    //Work here....
  }

}
