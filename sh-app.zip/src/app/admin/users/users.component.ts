import { Component, OnInit } from '@angular/core';
import { UserService, CommonService } from 'src/app/_core/services';
import { Router } from '@angular/router';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ChangepasswordComponent } from '../changepassword/changepassword.component';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styles: [`table {
    width: 100%;
  }`]
})
export class UsersComponent implements OnInit {
  displayedColumns: string[] = ['fullname', 'username', 'email', 'mobileno', 'status', 'doj', 'actions'];
  usersSource: any;


  constructor(private userService: UserService,
    private commonService: CommonService,
    private router: Router,
    public dialog: MatDialog) { }

  ngOnInit() {
    this.usersSource = [];
    this.getAllUsersFromAPI();
  }
  getAllUsersFromAPI() {
    this.usersSource = [];
    this.userService.getAllUsers().subscribe(response => {
      if (!this.commonService.validateAPIResponse(response)) {
        return; // show error message and return in case of any error from API
      }
      this.usersSource = response.data;
      // console.log(this.usersSource);
    })
  }
  changeUserStatus(name, userId) {
    if (confirm("Are you sure to change status of " + name)) {
      this.userService.changeStatus(userId).subscribe(response => {
        if (!this.commonService.validateAPIResponse(response)) {
          return; // show error message and return in case of any error from API
        }
        this.commonService.showSuccessMessage("User status changed successfully.")
        this.getAllUsersFromAPI();
      })
    }
  }
  changePassword(name, userId) {
    const dialogRef = this.dialog.open(ChangepasswordComponent, {
      width: '450px',
      data: { fullname: name, userId: userId }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // this.animal = result;
    });
  }

}
