import { ChangeDetectorRef,  Component,  NgZone,  OnDestroy,  
         ViewChild,  HostListener,  Directive,  AfterViewInit} from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { MenuItems } from '../menu-items';
import { CommonService } from '../../../_core/services'
import { Subscription } from 'rxjs';
@Component({
  selector: 'admin-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: []
})
export class AppSidebarComponent implements OnDestroy {
  mobileQuery: MediaQueryList;
  currentUser: any;
  private _mobileQueryListener: () => void;
  subscription: Subscription;
  constructor(
    changeDetectorRef: ChangeDetectorRef,
    media: MediaMatcher,
    public menuItems: MenuItems,
    private commonService: CommonService
  ) {
    this.mobileQuery = media.matchMedia('(min-width: 768px)');
    this._mobileQueryListener = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.subscription = this.commonService.getUserUpdatedDetails().
      subscribe(currentUser => {
        this.currentUser = currentUser;
      });
  }
  ngOnInit() {
    this.currentUser = this.commonService.getCurrentUser()
  }
  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListener);
  }
}