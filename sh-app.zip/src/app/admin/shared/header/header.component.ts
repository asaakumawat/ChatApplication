import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router'
import{AuthenticationService} from '../../../_core/services'
import { CommonService } from '../../../_core/services'
import { Subscription } from 'rxjs';
@Component({
  selector: 'admin-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  currentUser: any;
  subscription: Subscription;
  constructor(
    private router:Router,
    private authenticationService:AuthenticationService,
    private commonService:CommonService
  ) { 
    this.subscription = this.commonService.getUserUpdatedDetails().subscribe(currentUser => { this.currentUser = currentUser; });
  }

  ngOnInit() {
    this.currentUser = this.commonService.getCurrentUser();
  }
  logout()
  {
    this.authenticationService.logout();
    this.router.navigate(["/"]);
  }
}
