import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { AdminRoutingModule } from './admin-routing.module';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { AppSidebarComponent} from './shared/sidebar/sidebar.component';
import { LayoutComponent } from './shared/layout/layout.component';

import { MenuItems } from './shared/menu-items';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UsersComponent } from './users/users.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';

@NgModule({
  declarations: [HeaderComponent,FooterComponent,AppSidebarComponent, LayoutComponent,
    DashboardComponent,
    UsersComponent,
    ChangepasswordComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AdminRoutingModule,
  ],
 entryComponents:[
  ChangepasswordComponent
 ],
  providers:[
    MenuItems
  ]
})
export class AdminModule { }
