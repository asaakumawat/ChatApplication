const jwt = require( "jsonwebtoken" );

const logger = require( "../utilities/logger" );

const config = require( "../config" );

module.exports = function( req, res, next ) {
    const token = req.body.token || req.query.token || req.headers[ "authorization" ];

    if ( token ) {
        return jwt.verify( token, config.secret, function( err, decoded ) {
            if ( err ) {
                logger.error( err );
                return res.unauthorized("Failed to authenticate token.");
            }
            req.user = decoded;
            // //To generate new token on new request because JWT token has fix time to expire we can't increase there expiration time.
            // // const token = jwt.sign(decoded, config.secret, { expiresIn: 1140 }); 
            // // req.setHeader('Authorization',token)
            return next( );
        } );
    }
    return res.unauthorized("Failed to authenticate user.");
};
