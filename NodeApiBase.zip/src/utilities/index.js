var multer = require('multer');
var path = require('path');

exports.extractObject = (obj, keys) => {
    const returnObj = {};
    keys.forEach(key => { returnObj[key] = obj[key]; });

    return returnObj;
};

exports.UploadFile = () => {
    var storage = multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, 'uploads/')
        },
        filename: function (req, file, cb) {
            cb(null, Date.now() + path.extname(file.originalname)) //Appending extension
        }
    })

    var upload = multer({ storage: storage });
    return upload;
};

exports.UploadTempFile = () => {
    var storage = multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, 'uploads/temp/')
        },
        filename: function (req, file, cb) {
            cb(null, Date.now() + path.extname(file.originalname)) //Appending extension
        }
    })

    var upload = multer({ storage: storage });
    return upload;
};