//Create the hub connection
//NOTE: Server methods are defined as an object on the second argument
//https://www.npmjs.com/package/signalrjs
const SignalRJS = require('signalrjs'),
    signalR = SignalRJS();

module.exports = function (app) {
    app.use(signalR.createListener())

    signalR.on('CONNECTED', function (username) {
        console.log(signalR);
        console.log(username);
    });
    // signalR.on('DISCONNECTED', function () {
    //     console.log('DISCONNECTED');
    // });
    signalR.hub('chatHub', {
        SendMessage: function (message) {
            this.clients.all.invoke('messageReceived').withArgs([message + "from nodejs"])
            console.log('send:' + message);
        }

    });
}
