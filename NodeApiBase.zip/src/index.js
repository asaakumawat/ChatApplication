const express = require("express"),
    app = express(),
    cors = require('cors'),
    bodyParser = require("body-parser"),
    path = require("path"),
    config = require("./config");
    
const customResponses = require("./middlewares/customResponses");
const logger = require("./utilities/logger");

const port = process.env.PORT || config.port;
const ENV = process.env.NODE_ENV || config.env;

app.use(cors({ credentials: true, origin: 'http://localhost:4200' }));

require('./utilities/signalrService')(app); //register signlar

//app.use("uploads",express.static(__dirname + '../uploads'));
app.use("/uploads", express.static(path.join(__dirname, '../uploads')));
app.set("env", ENV);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(customResponses);

require("./config/mongoose")(app);
require("./app")(app);


// app.use("/" ,( req, res ) => {
//     //console.log(process.env.NODE_ENV)
//     res.notFound( );
// } );

app.use((req, res) => {
    res.notFound();
});

app.use((err, req, res, next) => {
    logger.error(err.stack);
    next(err);
});

// Don't remove next !!!!
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
    res.status(503).json({
        success: false,
        error: "server_error",
    });
});

app.listen(port, () => {
    logger.info(`Listening on port ${port}`);
});
