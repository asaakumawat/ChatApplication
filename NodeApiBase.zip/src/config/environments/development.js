module.exports = {
    host: "localhost",
    port: 4000, // change with development port
    mongoUrl: "mongodb://localhost:27017/usermanagment", // replace "usermanagment" with a proper db name
    logLevel: "debug", // can be chenged to error, warning, info, verbose or silly
    secret: "superSuperSecret",
    tokenTime: 1440,
    url: "http://localhost:4000/",
};
