const usersRouter = require( "./users/router" );
const userProfileRouter = require( "./userprofile/router" );
const contentManagerRouter = require( "./content-manager/router" );
// const articlesRouter = require( "./articles/router" );
const validateToken = require( "../middlewares/validateToken" );

module.exports = ( app ) => {
    app.use( "/user", usersRouter );
    app.use("/user/profile",validateToken,userProfileRouter);
    app.use("/content-manager",validateToken,contentManagerRouter);

};
