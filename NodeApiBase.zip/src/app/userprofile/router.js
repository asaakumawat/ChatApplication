require( "./model" );
const validateToken = require( "../../middlewares/validateToken" );
const controller = require( "./controller" );

const express = require( "express" );
const UploadFile=require('../../utilities').UploadFile();
const router = express.Router( );

router.get('/',controller.getProfile);

router.post('/',UploadFile.single('profilepic'),controller.saveProfile);

module.exports = router;