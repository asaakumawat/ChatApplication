const repository = require("./repository");

exports.getProfile = async (req, res) => {
    try {
        const userProfile = await repository.getProfileWithUserDetails(req.query.userid);
        res.success(userProfile);
    }
    catch (err) {
        res.send(err);
    }
};

exports.saveProfile = async (req, res) => {
    try {
        if (req.file) {
            req.body.profileimg = req.file.path;
        }
        const userProfile = await repository.saveProfile(req.body);
        res.success(userProfile);
    }
    catch (err) {
        res.send(err);
    }
};