const mongoose = require("mongoose");

const UserProfile = mongoose.model("UserProfile");

const getProfile = (id) => UserProfile.findById(id);

const getProfileByUserId = (userid) => {
    var userProfile = UserProfile.findOne({ userid: userid });
    return userProfile;
}

const getProfileWithUserDetails = (userid) => {
    var userProfile = UserProfile.findOne({ userid: userid }).populate('userid').exec();
    return userProfile;
}
const getAllUsersWithProfileDetails=()=>{
    var users = UserProfile.find()
    .populate({
        path: 'userid',
        match: { isadmin: false },
        select:['username','createdAt','isactive']
    }).exec();
    return users;
}
const saveProfile = async (data) => {
    var userProfile = await getProfileByUserId(data.userid);
    if (!userProfile) {
        userProfile = new UserProfile();
        userProfile.userid = data.userid;
    }
    // var   userProfile = new UserProfile();
    // userProfile.userid=data.userid;
    userProfile.fullname = data.fullname;
    userProfile.email = data.email;
    userProfile.mobileno = data.mobileno;
    userProfile.gender = data.gender;
    userProfile.dob = data.dob;
    userProfile.profileimg = data.profileimg;
    return userProfile.save();
}
module.exports = {
    getProfile,
    getProfileByUserId,
    getProfileWithUserDetails,
    getAllUsersWithProfileDetails,
    saveProfile
}