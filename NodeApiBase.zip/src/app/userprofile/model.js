const mongoose = require( "mongoose" );

const Schema = mongoose.Schema;


var userProfileSchema=new Schema({
    userid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    fullname:{type:String},
    email:{type:String},
    mobileno:{type:String},
    gender:{type:String},
    dob:{type:Date},
    profileimg:{type:String},
})

module.exports = mongoose.model( "UserProfile", userProfileSchema );