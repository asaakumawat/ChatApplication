const repository = require("./repository");
const config = require( "../../config/index" );

exports.getContentManager = async (req, res) => {
    try {
        const contentManager = await repository.getContentManager(req.params.id);
        res.success(contentManager);
    }
    catch (err) {
        res.send(err);
    }
};

exports.getUserContentManager = async (req, res) => {
    try {
        const contentManager = await repository.getContentManagerByUserId(req.query);
        res.success(contentManager);
    }
    catch (err) {
        res.send(err);
    }
};

exports.saveContentManager = async (req, res) => {
    try {
        const contentManager = await repository.saveContentManager(req.body);
        res.success(contentManager);
    }
    catch (err) {
        res.send(err);
    }
};
exports.deleteContentManager = async (req, res) => {
    try {
        const contentManager = await repository.deleteContentManager(req.query);
        res.success(contentManager);
    }
    catch (err) {
        res.send(err);
    }
};
exports.saveContentImages = async (req, res) => {
    try {
        console.log(req.files);
        if (req.files.length > 0) {
            return res.send({ path: config.url+req.files[0].path })
        }
        // const userProfile = await repository.saveProfile(req.body);
        return res.send("");
    }
    catch (err) {
        res.send(err);
    }
};