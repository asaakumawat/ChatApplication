const mongoose = require("mongoose");

const ContentManager = mongoose.model("ContentManager");

const getContentManager = (id) => ContentManager.findById(id);

const getContentManagerByUserId = async (data) => {
    var contentManager =await ContentManager.find({ userid: data.userid, isactive: true }).sort([[data.sortBy,data.sortDirection]]).skip(data.pageSize * data.pageIndex).limit(parseInt(data.pageSize));
    var count =await ContentManager.count({ userid: data.userid, isactive: true });
    return { items: contentManager, totalitems: count };
}
const getContentManagerBySystemName = (systemName) => {
    var contentManager = ContentManager.findOne({ systemname: systemname, isactive: true });
    return contentManager;
}

// const getContentDetialsWithUserDetails = () => {
//     var users = ContentManager.find()
//         .populate({
//             path: 'userid',

//             select: ['username', 'createdAt']
//         }).exec();
//     return users;
// }
const saveContentManager = async (data) => {
    var contentManager = await getContentManager(data.id);
    if (!contentManager) {
        contentManager = new ContentManager();
        contentManager.userid = data.userid;
    }
    // var   userProfile = new UserProfile();
    // userProfile.userid=data.userid;
    contentManager.title = data.title;
    contentManager.content = data.content;
    contentManager.systemName = data.systemName;
    return contentManager.save();
}
const deleteContentManager = async (data) => {
    var contentManager = await getContentManager(data.id);
    if (contentManager) {
        contentManager.isactive = false;
        return contentManager.save();
    }
    return null;
}
module.exports = {
    getContentManager,
    getContentManagerByUserId,
    getContentManagerBySystemName,
    // getContentDetialsWithUserDetails,
    saveContentManager,
    deleteContentManager
}