require( "./model" );
const controller = require( "./controller" );

const express = require( "express" );
const UploadFile=require('../../utilities').UploadFile();
const router = express.Router( );

router.get('/',controller.getUserContentManager);

router.get('/:id',controller.getContentManager);

router.post('/',controller.saveContentManager);

router.post('/delete',controller.deleteContentManager);

router.post('/uploadImages',UploadFile.any(),controller.saveContentImages);


module.exports = router;