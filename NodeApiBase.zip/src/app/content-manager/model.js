const mongoose = require("mongoose");

const Schema = mongoose.Schema;


var contentSchema = new Schema({
    userid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    title: { type: String },
    content: { type: String },
    systemname: { type: String },
    isactive: { type: Boolean,default:true },
}, {
        timestamps: true,
    });

module.exports = mongoose.model("ContentManager", contentSchema);