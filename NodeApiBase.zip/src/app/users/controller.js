const jwt = require("jsonwebtoken");
const config = require("../../config");
const extractObject = require("../../utilities/").extractObject;
const logger = require("../../utilities/logger");
const repository = require("./repository");
const userProfileRepository = require("../userprofile/repository");

exports.login = async (req, res) => {
    if (!req.body.password || !req.body.username) {
        res.preconditionFailed("Credentials required");
        return;
    }

    try {
        const user = await repository.findUserByUserName(req.body);
        if (!user || !user.checkPass(req.body.password)) {
            res.json({ success: false, message: "Authentication failed." });
            return;
        }
        if (!user.isactive) {
            res.failed("Your account is deactivated . Please contact to admin.");
            return;
        }

        const token = jwt.sign(user.toObject(), config.secret, { expiresIn: config.tokenTime });
        logger.info("User loged in with success. Login token", token);
        user.token = token;
        // get profile details for images path or full name
        var userProfile = await userProfileRepository.getProfileByUserId(user.id);
        if (userProfile) {
            user.profileimg = userProfile.profileimg;
            user.fullname = userProfile.fullname;
        }
        res.success(extractObject(
            user,
            ["username", "name", "token", "isadmin", "id", "profileimg", "fullname"],
        ));

    } catch (err) {
        res.throwCustomError(err.message);
    }
};

exports.register = async (req, res) => {
    const { user } = req;
    if (user) {
        logger.error("User already exists");
        res.preconditionFailed("existing_user");
        return;
    }

    try {
        const isExistUserName = await repository.findUserByUserName(req.body);
        if (isExistUserName) {
            res.preconditionFailed("Username already exists. Please another one.");
            return;
        }
        const savedUser = await repository.saveUser(req.body);
        userProfileRepository.saveProfile({ userid: savedUser.id, fullname: req.body.name })
        console.log(savedUser);
        res.success(extractObject(
            savedUser,
            ["id", "username"],
        ));
    } catch (err) {
        res.throwCustomError(err);
    }
};

exports.edit = async (req, res) => {
    try {
        const user = await repository.findUser(req.user.id);
        const editedUser = await repository.editUser(user, req.body);
        res.success(extractObject(
            editedUser,
            ["id", "username"],
        ));
    } catch (err) {
        res.send(err);
    }
};

exports.delete = async (req, res) => {
    try {
        const user = await repository.findUser(req.user.id);
        const deletedUser = await repository.deleteUser(user, req.body);
        res.success(extractObject(
            deletedUser,
            ["id", "username"],
        ));
    } catch (err) {
        console.log(err);
        res.send(err);
    }
};

exports.getAllUsers = async (req, res) => {
    try {
        const users = await userProfileRepository.getAllUsersWithProfileDetails();
        res.success(users);
    }
    catch (err) {
        res.throwCustomError(err);
    }
};

exports.changeUserStatus = async (req, res) => {
    try {
        const status = await repository.changeUserStatus(req.query.userId);
        res.success(status);
    }
    catch (err) {
        res.throwCustomError(err);
    }
};
exports.changePassword = async (req, res) => {
    try {
        if (!req.body.password || !req.body.newpassword || req.body.userid) {
            res.preconditionFailed("Details required");
            return;
        }

        const user = await repository.findUserById(req.body.userid);
        if (!user || !user.checkPass(req.body.password)) {
            res.failed("You entered worng current password.");
            return;
        }

        if (!user.isactive) {
            res.failed("Your account is deactivated . Please contact to system admin.");
            return;
        }

        var newuser = await repository.changePasswrod(user, req.body.newpassword);
        if (newuser) {
            res.success("Password changed successfully.");
            return;
        }
        else {
            res.failed("Something went worng. Please try again.");
            return;
        }

    }
    catch (err) {
        res.throwCustomError(err);
    }
};