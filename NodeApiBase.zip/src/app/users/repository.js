const mongoose = require("mongoose");

const User = mongoose.model("User");

const saveUser = (data) => {
    const user = new User(data);
    user.setPass(data.password);
    return user.save();
};

const editUser = (user, data) => {
    const { name, sex, age } = data;
    const currentUser = user;

    currentUser.name = name;
    currentUser.sex = sex;
    currentUser.age = age;
    return user.save();
};

const deleteUser = (user) => user.remove();

const findUserById = (id) => User.findById(id);

const findUserByUserName = (data) => {
    const user = data.username;
    return User.findOne({ username: { $regex: new RegExp(user, "i") }, isactive:true });
};
const changeUserStatus = async (userId) => {
    const user = await findUserById(userId);
    if (user) {
        user.isactive = !user.isactive;
        user.save();
        return true;
    }
    return false;
};
const changePasswrod = (user, newpassword) => {
    if (user) {
        user.setPass(newpassword);
        return user.save();
    }
    return null;
}

module.exports = {
    saveUser,
    editUser,
    deleteUser,
    findUserById,
    findUserByUserName,
    changeUserStatus,
    changePasswrod,
};
